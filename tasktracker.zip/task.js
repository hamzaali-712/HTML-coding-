let tasks = [];
const taskInput = document.getElementById('taskInput');
const addTaskBtn = document.getElementById('addTaskBtn');
const taskList = document.getElementById('taskList');
function addTask() {
    const taskText = taskInput.value;
    if (taskText.trim() !== '') {
        const task = {
            id: Date.now(), 
            description: taskText,
            completed: false
        };
        tasks.push(task);
        taskInput.value = '';
        renderTasks();
    }
}
function toggleTask(id) {
    for (let i = 0; i < tasks.length; i++) {
        if (tasks[i].id === id) {
            tasks[i].completed = !tasks[i].completed;
            break; 
        }
    }
    renderTasks();
}
function deleteTask(id) {
    let newTasks = [];
    for (let i = 0; i < tasks.length; i++) {
        if (tasks[i].id !== id) {
            newTasks.push(tasks[i]);
        }
    }
    tasks = newTasks;
    renderTasks();
}
function renderTasks() {
    taskList.innerHTML = '';
    let activeTasks = [];
    let completedTasks = [];
    for (let i = 0; i < tasks.length; i++) {
        if (tasks[i].completed) {
            completedTasks.push(tasks[i]);
        } else {
            activeTasks.push(tasks[i]);
        }
    }
    if (tasks.length === 0) {
        taskList.innerHTML = '<li class="empty-state">No tasks yet. Add a new task to get started!</li>';
        return; 
    }
    if (activeTasks.length > 0) {
        const activeTitle = document.createElement('div');
        activeTitle.className = 'active-tasks-title';
        activeTitle.textContent = 'Active Tasks';
        taskList.appendChild(activeTitle);
        for (let i = 0; i < activeTasks.length; i++) {
            addTaskToDOM(activeTasks[i]);
        }
    }
    if (completedTasks.length > 0) {
        const completedTitle = document.createElement('div');
        completedTitle.className = 'completed-tasks-title';
        completedTitle.textContent = 'Completed Tasks';
        taskList.appendChild(completedTitle);
        for (let i = 0; i < completedTasks.length; i++) {
            addTaskToDOM(completedTasks[i]);
        }
    }
}
function addTaskToDOM(task) {
    const li = document.createElement('li');
    li.className = 'task-item';
    if (task.completed) {
        li.className += ' completed';
    }
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'task-checkbox';
    checkbox.checked = task.completed;
    checkbox.onchange = function() {
        toggleTask(task.id);
    };
    const span = document.createElement('span');
    span.className = 'task-description';
    if (task.completed) {
        span.className += ' completed';
    }
    span.textContent = task.description;
    const button = document.createElement('button');
    button.className = 'delete-btn';
    button.textContent = 'Delete';
    button.onclick = function() {
        deleteTask(task.id);
    };
    li.appendChild(checkbox);
    li.appendChild(span);
    li.appendChild(button);
    taskList.appendChild(li);
}
addTaskBtn.addEventListener('click', addTask);
taskInput.addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        addTask();
    }
});
renderTasks();